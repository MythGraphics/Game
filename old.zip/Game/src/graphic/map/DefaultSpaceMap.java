/*
 *
 */

package graphic.map;

/**
 *
 * @author  Martin Pröhl alias MythGraphics
 * @version 1.0.0
 *
 */

import graphic.AnimatedSprite;
import graphic.Animation;
import graphic.MoveableSprite;
import graphic.Sprite;
import static graphic.io.BinaryIO.*;
import graphic.io.TilesetUtility;
import static graphic.map.DefaultMapTile.*;
import java.awt.Color;
import java.awt.Point;
import java.awt.image.BufferedImage;
import java.util.HashMap;
import java.util.Map;

public class DefaultSpaceMap extends GameMap {

    public final static Color AMBIENT_COLOR = new Color(50, 50, 50);

    private Animation[] playerAni;
    private Animation enemyAni;

    private final Map<DefaultMapTile, BufferedImage> imgMap = new HashMap<>();

    public DefaultSpaceMap(char[][] tileMap) {
        super(tileMap);
        init();
    }

    @Override
    public Color getAmbientColor() {
        return AMBIENT_COLOR;
    }

    @Override
    protected void loadSprites() {
        BufferedImage[][] tileset = TilesetUtility.getAnimationSet(
            loadImage( TILESET+"spaceship/creatures2.png" ), 0, 0, 32, 32, 3
        );
        BufferedImage[] corpseset = TilesetUtility.getSpriteSet(
            loadImage( TILESET+"spaceship/creatures2.png" ), new Point( 3*32, 0 ), 0, 0, 32, -1
        );
        imgMap.put( ENVIRONMENT_A, loadImage( SPRITE+"land/Straw1.png" ));
        imgMap.put( WALL0, loadImage( SPRITE+"spaceship/wall1.png" ));
        imgMap.put( WALL1, loadImage( SPRITE+"spaceship/wall2.png" ));
        imgMap.put( WALL2, loadImage( SPRITE+"spaceship/wall3.png" ));
        imgMap.put( WALL3, loadImage( SPRITE+"spaceship/wall4.png" ));
        imgMap.put( WALL4, loadImage( SPRITE+"spaceship/wall5.png" ));
        imgMap.put( WALL5, loadImage( SPRITE+"spaceship/wall6.png" ));
        imgMap.put( WALL6, loadImage( SPRITE+"spaceship/wall7.png" ));
        imgMap.put( WALL7, loadImage( SPRITE+"spaceship/wall8.png" ));
        imgMap.put( SPACE, loadImage( SPRITE+"spaceship/floor.png" ));
        imgMap.put( CORPSE_ENEMY, corpseset[5] );
        imgMap.put( CORPSE_PLAYER, corpseset[3] );
        enemyAni = new Animation(tileset[5], true);
        playerAni = Animation.buildDirectionalAnimationSet( TilesetUtility.getAnimationSet(
            loadImage( TILESET+"spaceship/spacemarine.png" ), 0, 0, 32, 32, 3
        ));
        for (Animation a : playerAni) {
            a.slowDown();
        }
    }

    @Override
    Block getBlock(IsMapTile tile, int x, int y, int tileSize) {
        switch (tile) {
            case PLAYER:
                MoveableSprite player = new MoveableSprite(
                    playerAni, imgMap.get( CORPSE_PLAYER ), x, y, tileSize, PLAYER, getMaxPoint()
                );
                return player;
            case ENVIRONMENT_A:
            case WALL0:
            case WALL1:
            case WALL2:
            case WALL3:
            case WALL4:
            case WALL5:
            case WALL6:
            case WALL7:
            case WALL8:
            case EXIT:
            case SPACE:
            case SPACEHOLDER:
                return new Sprite( imgMap.get( tile ), x, y, tileSize, tile );
            case ENEMY:
                // da sich mehrere Gegner die selbe Animation teilen, diese kopieren
                AnimatedSprite enemy = new AnimatedSprite(
                    enemyAni.copy(), imgMap.get( CORPSE_ENEMY ), x, y, tileSize, ENEMY
                );
                return enemy;
            default:
                return super.getBlock(tile, x, y, tileSize);
        }
    }

}
