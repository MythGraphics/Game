/*
 *
 */

package game.routine;

/**
 *
 * @author  Martin Pröhl alias MythGraphics
 * @version 1.0.0
 *
 */

import game.GameFrame;
import game.Player;
import game.resource.Resource;
import static game.resource.Resource.ResourceType.AIR;
import static game.resource.Resource.ResourceType.HEALTH;
import game.resource.ResourceConsumeListener;
import static graphic.io.BinaryIO.TILESET;
import static graphic.io.BinaryIO.loadImage;
import graphic.io.TilesetUtility;
import static graphic.map.DefaultMapTile.BUBBLE;
import graphic.texter.DialogOutputListener;
import graphic.map.*;
import graphic.Sprite;

public class UWMapGameRoutine extends GameRoutine implements ResourceConsumeListener {

    private final Player player;
    private final GameFrame gameFrame;

    public UWMapGameRoutine(UWMap map, GameFrame gameFrame) {
        this.gameFrame = gameFrame;
        this.player = initPlayer(map, gameFrame);
    }

    @Override
    public Player getPlayer() {
        return player;
    }

    @Override
    public DialogOutputListener getDialogListener(CollisionEvent e) {
        return gameFrame.textFrame;
    }

    private Player initPlayer(UWMap map, GameFrame frame) {
        Resource health = new Resource("Gesundheit", HEALTH, 1000, 1000);
        health.addResourceChangeListener(frame);
        Resource air = map.getResource();
        air.addResourceChangeListener(frame);
        air.addResourceConsumeListener(this);
        Player player = new Player(GameFrame.playerName, frame.textFrame, health, air);
        player.setImg( TilesetUtility.getSpriteSetHorizontal(
            loadImage( TILESET+"player/girl_red_swimsuit.png" ), 140, 200, 4
        )[0]);
        return player;
    }

    @Override
    public void resourceConsumePerformed(Resource r, int use, int overuse) {
        if (overuse > 0 && r.getType() == AIR ) {
            player.getResource(HEALTH).forceConsume(overuse);
        }
    }

    @Override
    public void collisionPerformed(CollisionEvent e) {
        switch( e.getTarget().getType() ) {
            case BUBBLE -> {
                getPlayer().getResource(AIR).recharge(100);
                Block block = e.getTarget();
                if (block instanceof Sprite sprite) {
                    sprite.setImage(null);
                }
            }
            default -> {
                super.collisionPerformed(e);
            }
        }
    }

}
